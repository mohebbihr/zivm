This is the new, restructured netperf heirarchy on ftp.netperf.org. 

The tar and zip files at the top level will be the source for the most
current released version of netperf. 

The "pocket" zip file is an ancient port of netperf to PocketPC. 
I've not looked at it myself and am merely passing it along.

The archive directory contains the source distributions of past
revisions of netperf. For a better view of netperf's past lives you 
can consult the subversion repository at:
 
  http://www.netperf.org/svn/netperf2

The binaries directory is a sparse heirarchy of ancient, pre-compiled
versions of netperf and netserver.  I am not at all certain I want to 
remain in the business of distributing binaries because there are so many
different platforms on which netperf runs.  This is why the binaries you
will find there are so old.

If you do not find a binary in the sparse heirarchy, sending me email
is unlikely to uncover one.  You are better-off asking in netperf-talk
or in one of the netnews/usenet groups such as comp.benchmarks,
comp.protocols.tcp-ip, or a group specific to the Operating System of
your choice.

The experimental directory contains not-yet-released revisions of
netperf. You are free to experiment with these, and I would very much
like your feedback.  Better still, try the "top of trunk" version which
you can grab with a subversion client pointed at:

  http://www.netperf.org/svn/netperf2/trunk
  
It might be best to only use "released" versions of netperf for important
papers and presentations and such.  If you do decide to use a top-of-trunk
version, please include the repository revision number in your writeup.

The netperf homepage on the web and other netperf resources can be found via:

http://www.netperf.org/

happy benchmarking,

rick jones <rick.jones2@hp.com>
